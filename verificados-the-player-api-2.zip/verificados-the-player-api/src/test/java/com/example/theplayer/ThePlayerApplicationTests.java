package com.example.theplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThePlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
